 <script>
        tinymce.init({
            selector: 'textarea',  // Use <textarea> elements as TinyMCE editors
            plugins: 'autoresize',
            toolbar: 'undo redo | formatselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat',
            menubar: false,
            min_height: 200,
            autoresize_bottom_margin: 16
        });
    </script>


